//srdce celé kalkulačky

let data = DATA;

function render() {
    const container = document.getElementById("celky");
    container.innerHTML = "";

    const celekIds = Object.keys(data.celky);

    if (celekIds.length === 0) {
        container.innerHTML = "<i>Zatím není přidán žádný celek</i>";
        return;
    }

    celekIds.forEach(celekId => {
        const celek = data.celky[celekId];

        const div = document.createElement("div");
        div.className = "celek";

        div.innerHTML = `
			<h3 class="celek-header">
				<button onclick="moveCelekUp('${celekId}')">↑</button>
			<button onclick="moveCelekDown('${celekId}')">↓</button>

            
                <!-- Název celku -->
                <input class="celek-name" value="${celek.name}"
                       onchange="data.celky['${celekId}'].name=this.value">

                <!-- + Položka hned vedle -->
                <button class="add-polozka" onclick="addPolozka('${celekId}')">➕ Položka</button>

                <!-- Mazací tlačítko odsunuté -->
                <button class="delete-celek" onclick="deleteCelek('${celekId}')">Odebrat celek❌</button>
            </h3>

            <div id="polozky-${celekId}"></div>
        `;

        container.appendChild(div);

        const polozkyDiv = div.querySelector(`#polozky-${celekId}`);
        Object.keys(celek.polozky).forEach(pid => {
            polozkyDiv.appendChild(renderPolozka(celekId, pid));
        });

        // Celek Součet – bezpečné načtení všech hodnot
		const totalPlocha = celek.totalPlocha ?? 0;
		const totalObjem = celek.totalObjem ?? 0;
		const totalUctPl = celek.totalUctPl ?? 0;
		const totalUctOb = celek.totalUctOb ?? 0;
		const nakupkaCena = celek.nakupkaCena ?? 0;
		const ursCena = celek.ursCena ?? 0;
		const firmaCena = celek.firmaCena ?? 0;
		
        const soucetDiv = document.createElement("div");
		soucetDiv.className = "celek-soucet";
		soucetDiv.innerHTML = `
			<b>Celek Součet:</b>
			plocha: <input class="readonly small" value="${celek.totalPlocha}" readonly>
			objem: <input class="readonly small" value="${celek.totalObjem}" readonly>
			účt. plocha: <input class="readonly small" value="${celek.totalUctPl.toFixed(3)}" readonly>
			účt. objem: <input class="readonly small" value="${celek.totalUctOb.toFixed(3)}" readonly>
			Nákupka: <input class="readonly small" value="${celek.nakupkaCena}" readonly>
			URS: <input class="readonly small" value="${celek.ursCena}" readonly>
			Firma: <input class="readonly small" value="${celek.firmaCena}" readonly>
		`;

        div.appendChild(soucetDiv);
    });
	
	// ➕ Zde přepočítat a vykreslit globální ceny
    recalcGlobalCeny();
    renderGlobalCeny();
}



function renderPolozka(celekId, pid) {
    const p = data.celky[celekId].polozky[pid];

    // ➕ defaulty
    if (p.unitFactor === undefined) p.unitFactor = 1;
    if (p.namerFactor === undefined) p.namerFactor = 1;

    const div = document.createElement("div");
    div.className = "polozka";

    div.innerHTML = `

        <!-- ================= PRVNÍ ŘÁDEK ================= -->
        <div class="row row-main">
			<button onclick="movePolozkaUp('${celekId}','${pid}')">↑</button>
			<button onclick="movePolozkaDown('${celekId}','${pid}')">↓</button>
			<button class="copy-polozka" title="Zkopírovat položku" onclick="copyPolozka('${celekId}','${pid}')">📄</button>


            <!-- Název položky -->
            <input type="text" value="${p.name}"
                onchange="data.celky['${celekId}'].polozky['${pid}'].name=this.value">

            <!-- Materiál -->
            <select onchange="onMaterialChange('${celekId}','${pid}', this.value)">
                ${renderMaterials(p.material)}
            </select>

            <!-- Rozměry -->
            <span>a</span>
            <input type="number" value="${p.a}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].a=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <span>b</span>
            <input type="number" value="${p.b}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].b=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <span>v</span>
            <input type="number" value="${p.v}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].v=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <!-- Výsledky geometrie -->
            <span>pl(m²)</span>
			<input class="readonly small pl-value ${p.cena.priceFromM2 ? 'highlight-m2' : ''}" value="${p.pl}" readonly>

			<span>ob(m³)</span>
			<input class="readonly small ob-value ${!p.cena.priceFromM2 ? 'highlight-m3' : ''}" value="${p.ob}" readonly>


            <!-- Přepínač m² / m³ -->
            <button
                class="price-switch ${p.cena.priceFromM2 ? 'm2' : 'm3'}"
                onclick="togglePriceMode(this, '${celekId}', '${pid}')">
                ${p.cena.priceFromM2 ? 'cena z m²' : 'cena z m³'}
            </button>

            <!-- Modifikátor -->
            <span>modif.</span>
            <input type="number"
                step="0.01"
                value="${p.unitFactor}"
                title="Např. 1.7 = t / m³"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].unitFactor=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <!-- Náměr -->
            <span>náměr %</span>
            <input type="number"
                step="1"
                value="${(p.namerFactor - 1) * 100}"
                title="Rezerva materiálu v %"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].namerFactor = 1 + (+this.value / 100);
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <!-- Účtované množství -->
            <span>účt. množ.</span>
				<input class="readonly small uctValue ${p.cena.priceFromM2 ? 'highlight-m2' : 'highlight-m3'}"
					   value="${
						   ((p.cena.priceFromM2 ? p.pl : p.ob) * p.unitFactor * p.namerFactor).toFixed(3)
					   }"
					   readonly>


        </div>

        <!-- ================= DRUHÝ ŘÁDEK ================= -->
        <div class="row row-price">

            <!-- Cena jednotková -->
            <span>Jednotka:</span>
            Nákupka <input type="number" value="${p.cena.nakupkaUnit}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].cena.nakupkaUnit=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">
            URS <input type="number" value="${p.cena.ursUnit}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].cena.ursUnit=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">
            Firma <input type="number" value="${p.cena.firmaUnit}"
                onchange="
                    data.celky['${celekId}'].polozky['${pid}'].cena.firmaUnit=+this.value;
                    recalcPolozka('${celekId}','${pid}');
                    render();
                ">

            <!-- Cena celkem -->
            <span>Celkem:</span>
            Nákupka <input class="readonly" value="${p.cena.nakupkaTotal}" readonly>
            URS <input class="readonly" value="${p.cena.ursTotal}" readonly>
            Firma <input class="readonly" value="${p.cena.firmaTotal}" readonly>

            <!-- Mazání -->
            <button onclick="deletePolozka('${celekId}','${pid}')">Odebrat položku ❌</button>

        </div>
    `;

    return div;
}


function renderGlobalCeny() {
    document.getElementById("globalNakupka").textContent = data.globalData.globalCeny.nakupka.cena.toFixed(2);
    document.getElementById("globalURS").textContent = data.globalData.globalCeny.urs.cena.toFixed(2);
    document.getElementById("globalFirma").textContent = data.globalData.globalCeny.firma.cena.toFixed(2);
}



function renderMaterials(selected) {
    let html = "";
    for (const key in data.globalData.material) {
        const m = data.globalData.material[key];
        html += `<option value="${key}" ${key === selected ? "selected" : ""}>${m.name}</option>`;
    }
    return html;
}

// PŘEPOČTY
function recalculate() {
    for (const cid in data.celky) {
        if (cid === "nextCelekId") continue;
        const celek = data.celky[cid];

        let totalPl = 0;
        let totalOb = 0;
        let n = 0, u = 0, f = 0;

        for (const pid in celek.polozky) {
            if (pid === "nextPolozkaId") continue;
            const p = celek.polozky[pid];

            p.pl = p.a * p.b;
            p.ob = p.a * p.b * p.v;

            const base = p.cena.priceFromM2 ? p.pl : p.ob;

            p.cena.nakupkaTotal = base * p.cena.nakupkaUnit;
            p.cena.ursTotal = base * p.cena.ursUnit;
            p.cena.firmaTotal = base * p.cena.firmaUnit;

            totalPl += p.pl;
            totalOb += p.ob;
            n += p.cena.nakupkaTotal;
            u += p.cena.ursTotal;
            f += p.cena.firmaTotal;
        }

        celek.totalPlocha = totalPl;
        celek.totalObjem = totalOb;
        celek.nakupkaCena = n;
        celek.ursCena = u;
        celek.firmaCena = f;
    }

    render();
}

function onMaterialChange(celekId, pid, materialKey) {
    const p = data.celky[celekId].polozky[pid];
    p.material = materialKey;

    if (materialKey && data.globalData.material[materialKey]) {
        const defaultCena = data.globalData.material[materialKey].unitCenaDefault;

        p.cena.nakupkaUnit = defaultCena;
        p.cena.ursUnit = defaultCena;
        p.cena.firmaUnit = defaultCena;
    }

    recalculate();
}

function onPriceModeChange(celekId, pid, fromM2) {
    data.celky[celekId].polozky[pid].cena.priceFromM2 = fromM2;
    recalculate();
}

function togglePriceMode(btn, celekId, pid) {
    const p = data.celky[celekId].polozky[pid];
    const newValue = !p.cena.priceFromM2;

    // přepnout logiku v JSONu
    onPriceModeChange(celekId, pid, newValue);

    // přepnout vzhled tlačítka
    btn.classList.toggle('m2', newValue);
    btn.classList.toggle('m3', !newValue);
    btn.textContent = newValue ? 'cena z m²' : 'cena z m³';

    // změnit barvu polí
    const div = btn.closest('.polozka');
    const plInput = div.querySelector('.pl-value');
    const obInput = div.querySelector('.ob-value');
	const uctInput = div.querySelector('.uctValue');

    if(newValue){
        plInput.classList.add('highlight-m2');
        plInput.classList.remove('highlight-m3');
        obInput.classList.remove('highlight-m2','highlight-m3');
		uctInput.classList.add('highlight-m2');
		uctInput.classList.remove('highlight-m3');
    } else {
        obInput.classList.add('highlight-m3');
        obInput.classList.remove('highlight-m2');
        plInput.classList.remove('highlight-m2','highlight-m3');
		uctInput.classList.add('highlight-m3');
		uctInput.classList.remove('highlight-m2');
    }
	
	// ➕ NOVÉ – okamžitý přepočet
    recalcPolozka(celekId, pid);   // přepočet položky
    recalcCelek(celekId);          // přepočet součtu celku
    recalcGlobalCeny();             // přepočet globálních cen
    render();                       // aktualizace UI
}





function recalcPolozka(celekId, pid) {
    const p = data.celky[celekId].polozky[pid];

    // ochrany
    if (p.unitFactor === undefined) p.unitFactor = 1;
    if (p.namerFactor === undefined) p.namerFactor = 1;

    // geometrie
    p.pl = +(p.a * p.b).toFixed(3);
    p.ob = +(p.a * p.b * p.v).toFixed(3);

    // základ množství
    const baseQty = p.cena.priceFromM2 ? p.pl : p.ob;

    // ➕ NOVÉ: modifikátor + námer
    const qty =
        baseQty *
        p.unitFactor *
        p.namerFactor;

    // ceny
    p.cena.nakupkaTotal = +(qty * p.cena.nakupkaUnit).toFixed(2);
    p.cena.ursTotal     = +(qty * p.cena.ursUnit).toFixed(2);
    p.cena.firmaTotal   = +(qty * p.cena.firmaUnit).toFixed(2);
}


function recalcAll() {
    for (const celekId in data.celky) {
        const celek = data.celky[celekId];

        for (const pid in celek.polozky) {
            recalcPolozka(celekId, pid);
        }
    }

    render();
}

function recalcGlobalCeny() {
    let totalNakupka = 0;
    let totalURS = 0;
    let totalFirma = 0;

    Object.keys(data.celky).forEach(celekId => {
        const celek = data.celky[celekId];
        Object.keys(celek.polozky).forEach(pid => {
            const p = celek.polozky[pid];
            // přepočet položky
            recalcPolozka(celekId, pid);

            totalNakupka += p.cena.nakupkaTotal;
            totalURS += p.cena.ursTotal;
            totalFirma += p.cena.firmaTotal;
        });
    });

    data.globalData.globalCeny.nakupka.cena = totalNakupka;
    data.globalData.globalCeny.urs.cena = totalURS;
    data.globalData.globalCeny.firma.cena = totalFirma;
}



// Přepočítá součty celku podle všech jeho položek
function recalcCelek(celekId) {
    const celek = data.celky[celekId];

    // inicializace součtů
    let totalPl = 0;
    let totalOb = 0;
    let totalUctPl = 0;
    let totalUctOb = 0;
    let totalNakupka = 0;
    let totalURS = 0;
    let totalFirma = 0;

    Object.keys(celek.polozky).forEach(pid => {
        const p = celek.polozky[pid];

        // přepočítáme položku
        recalcPolozka(celekId, pid);

        // sečteme základní plochu a objem
        totalPl += p.pl;
        totalOb += p.ob;

        // účtované množství podle priceFromM2
        const uct = (p.cena.priceFromM2 ? p.pl : p.ob) * p.unitFactor * p.namerFactor;
        totalUctPl += p.cena.priceFromM2 ? uct : 0;
        totalUctOb += !p.cena.priceFromM2 ? uct : 0;

        // ceny
        totalNakupka += p.cena.nakupkaTotal;
        totalURS += p.cena.ursTotal;
        totalFirma += p.cena.firmaTotal;
    });

    // uložíme zpět do celku
    celek.totalPlocha = totalPl;
    celek.totalObjem = totalOb;
    celek.totalUctPl = totalUctPl;
    celek.totalUctOb = totalUctOb;
    celek.nakupkaCena = totalNakupka;
    celek.ursCena = totalURS;
    celek.firmaCena = totalFirma;
}







// PŘIDÁVANÍ a MAZÁNÍ
function addCelek() {
    const id = data.nextCelekId++;

    data.celky[id] = {
        name: "Nový celek",
        polozky: {},
        nextPolozkaId: 1,
        totalPlocha: 0,
        totalObjem: 0,
        totalUctPl: 0,       // ← přidáno
        totalUctOb: 0,       // ← přidáno
        nakupkaCena: 0,
        ursCena: 0,
        firmaCena: 0
    };

    render();
}



function deleteCelek(id) {
    delete data.celky[id];
    render();
}

function addPolozka(celekId) {
    const celek = data.celky[celekId];
    const pid = celek.nextPolozkaId++;

    celek.polozky[pid] = {
        name: "Nová položka",
        material: "",
        a: 0,
        b: 0,
        v: 0,
        pl: 0,
        ob: 0,
		unitFactor: 1,   // např. 1.7 t / m3
		namerFactor: 1,  // 1 = 0 %, 1.1 = +10 %
        cena: {
            nakupkaUnit: 0,
            ursUnit: 0,
            firmaUnit: 0,
            nakupkaTotal: 0,
            ursTotal: 0,
            firmaTotal: 0,
            priceFromM2: true
        }
    };

    render();
}


function deletePolozka(cid, pid) {
    delete data.celky[cid].polozky[pid];
    render();
}

render();




// PŘESUNY
function movePolozkaUp(celekId, pid) {
    const polozky = data.celky[celekId].polozky;
    const keys = Object.keys(polozky);
    const index = keys.indexOf(pid);
    if (index > 0) {
        // přehodit klíče
        [polozky[keys[index - 1]], polozky[keys[index]]] = 
        [polozky[keys[index]], polozky[keys[index - 1]]];
        render();
    }
}

function movePolozkaDown(celekId, pid) {
    const polozky = data.celky[celekId].polozky;
    const keys = Object.keys(polozky);
    const index = keys.indexOf(pid);
    if (index < keys.length - 1) {
        [polozky[keys[index]], polozky[keys[index + 1]]] =
        [polozky[keys[index + 1]], polozky[keys[index]]];
        render();
    }
}

function moveCelekUp(celekId) {
    const keys = Object.keys(data.celky);
    const index = keys.indexOf(celekId);
    if (index > 0) {
        const temp = data.celky[keys[index - 1]];
        data.celky[keys[index - 1]] = data.celky[keys[index]];
        data.celky[keys[index]] = temp;
        render();
    }
}

function moveCelekDown(celekId) {
    const keys = Object.keys(data.celky);
    const index = keys.indexOf(celekId);
    if (index < keys.length - 1) {
        const temp = data.celky[keys[index + 1]];
        data.celky[keys[index + 1]] = data.celky[keys[index]];
        data.celky[keys[index]] = temp;
        render();
    }
}


function saveData() {
    // vezmeme název souboru z textového pole
    const fileNameInput = document.getElementById("saveFileName");
    let fileName = fileNameInput.value.trim();  // bereme skutečnou hodnotu
    if (!fileName) fileName = "kalkulacka";    // default
    if (!fileName.endsWith(".json")) fileName += ".json";

    // Deep copy objektu data, aby se nezměnily reference
    const dataToSave = JSON.parse(JSON.stringify(data));

    // Ujistíme se, že nextPolozkaId u každého celku je uloženo
    Object.keys(dataToSave.celky).forEach(celekId => {
        const celek = dataToSave.celky[celekId];
        if (celek.nextPolozkaId === undefined) celek.nextPolozkaId = 1;
    });

    // Vytvoření blobu a stažení
    const blob = new Blob([JSON.stringify(dataToSave, null, 2)], {type: "application/json"});
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    a.click();

    URL.revokeObjectURL(url);
}


// SAVE and LOAD 
function saveDataServer() {
    const fileNameInput = document.getElementById("saveFileName");
    let fileName = fileNameInput.value.trim();
    if (!fileName) fileName = "kalkulacka";  // default

    fetch("/save-json", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            fileName: fileName,
            content: data  // tady je tvoje celá struktura JSON
        })
    })
    .then(res => res.json())
    .then(res => {
        if(res.status === "ok") {
            alert("Soubor uložen: " + res.path);
        } else {
            alert("Chyba při ukládání JSONu");
        }
    })
    .catch(err => {
        console.error(err);
        alert("Chyba při ukládání JSONu");
    });
}



function loadJSON(event) {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    fetch("/load-json", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(res => {
        if (res.status === "ok") {
            data = res.content;  // nahradíme stávající data
            render();            // render nové struktury
            recalcGlobalCeny();  // přepočítat global ceny
            renderGlobalCeny();  // vykreslit global ceny
            alert("JSON načten: " + file.name);
        } else {
            alert("Chyba při načítání JSONu: " + res.message);
        }
    })
    .catch(err => {
        console.error(err);
        alert("Chyba při načítání JSONu");
    });

    // reset file input, aby šlo načíst stejný soubor znovu
    event.target.value = "";
}



function copyPolozka(celekId, pid) {
    const celek = data.celky[celekId];
    const orig = celek.polozky[pid];
    
    // nový pid
    const newPid = celek.nextPolozkaId++;
    
    // vytvořit novou položku s kopírovanými hodnotami
    celek.polozky[newPid] = JSON.parse(JSON.stringify(orig));
    
    // přepočet součtů a render
    recalcPolozka(celekId, newPid);
    recalcCelek(celekId);
    recalcGlobalCeny();
    render();
}


